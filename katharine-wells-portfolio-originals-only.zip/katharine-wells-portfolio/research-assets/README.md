# Original research assets — upload checklist

This directory intentionally contains no slides or maps: the source presentations were identified in the user's project library, but the original binary files could not be exported into this work session.

**Do not publish the website as a portfolio of original visuals until those originals are added.** This avoids passing concept art or ChatGPT-produced graphics off as research.

Required original files to supply (the actual originals, not screenshots made by ChatGPT):

- `Symposium Poster-LLResearch Summer 2026(2).pptx` — LLOI poster with school-zone maps.
- `MLS Symposium Poster (1)(2).pptx` — original MLS research poster.
- `Our SEDAAG Presentation (1).pptx` — original SEDAAG deck.
- `SEDAAG_MLS_Presentation_Draft.pdf` — verify whether this is the version intended for public release.
- Approved exports of your ArcGIS map figures, ideally `.png` or `.svg`, with map legends, north arrows, scale bars, sources, and captions intact.

Optional (only if you want them public): `SOC401_ Capstone Methods Section.docx` and the DSST 389 metro-systems proposal/data.

When supplied, the website should:
1. Put each approved original in `research-assets/` as an unmodified download.
2. Extract any featured images from the original slide or map files without changing the data.
3. Display caption, original source filename, author/team credit, date, and method for every figure.
4. Link to the corresponding original download.
5. Keep unpublished manuscripts, MLS property-level locations, and data with restricted redistribution private until released by collaborators.
